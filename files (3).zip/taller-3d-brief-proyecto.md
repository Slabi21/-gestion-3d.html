# Taller 3D — Gestión de clientes, pedidos, prospectos y catálogo

Documento de referencia del proyecto. Subir este archivo como "project knowledge" (reemplazando cualquier versión anterior) y, en cada chat nuevo donde se siga trabajando, adjuntar también la última versión de `gestion-3d.html`, `catalogo-3d.html`, `sw.js` y `sw-catalogo.js`.

---

## Qué es

Dos mini-apps web (archivos HTML, sin backend propio) que un negocio de impresión 3D usa desde el celular:

1. **`gestion-3d.html`** — gestión interna: clientes, pedidos y prospectos. Soporta **varios vendedores** que sincronizan contra una base compartida, más un modo "casa matriz" que ve el consolidado de todos y tiene un mini-dashboard.
2. **`catalogo-3d.html`** — catálogo de productos con fotos, pensado para compartir por WhatsApp con clientes. Tiene su propio modo "editor" para cargar/editar productos, filtro por categoría, orden manual y funciona offline.

Ambos archivos viven en el mismo repo de GitHub Pages y comparten el mismo proyecto de Firebase como backend.

## Dónde y cómo viven

- **Archivos**: `gestion-3d.html`, `catalogo-3d.html`, `sw.js`, `sw-catalogo.js` — todos en la misma carpeta del repo (GitHub Pages).
- **Uso real**: se abren desde el celular (Android) con Chrome y se agregan a la pantalla de inicio ("Agregar a pantalla de inicio"). Quedan con ícono propio y se abren como apps.
- **Repo**: `slabi21.github.io` (el catálogo se referencia en el código como `https://slabi21.github.io/-gestion-3d.html/catalogo-3d.html`).
- **Service workers**: cada app tiene el suyo, mismo criterio en los dos (con internet siempre pide la versión más nueva al servidor con `cache: 'no-store'` y la guarda; sin internet usa la última copia guardada):
  - `sw.js` → cachea el cascarón de `gestion-3d.html`. `CACHE_NAME` actual: `taller3d-shell-v12`.
  - `sw-catalogo.js` → cachea el cascarón de `catalogo-3d.html`. `CACHE_NAME` actual: `taller3d-catalogo-shell-v5`.
  - **Regla importante**: cada vez que se sube una versión nueva de cualquiera de los dos HTML, hay que subir el número de `CACHE_NAME` en el `sw` correspondiente, si no los celus que ya la tenían instalada van a seguir viendo una copia vieja.
- Además del cascarón, `catalogo-3d.html` tiene la **caché offline de Firestore** habilitada (`enableIndexedDbPersistence`), así los datos de los productos (no solo el HTML) sobreviven sin señal.

## Backend: Firebase

Proyecto: **`agenda-clientes-3s`** (Firestore, plan gratuito Spark, región `southamerica-east1`; Authentication con proveedor Anónimo habilitado — cada celular se identifica sin login de Google ni contraseña).

- La config (`FIREBASE_CONFIG`) está pegada directamente en el código de `gestion-3d.html` y `catalogo-3d.html`.
- Reglas de Firestore: permiten leer/escribir a cualquiera autenticado (aunque sea de forma anónima) — alcanza para este uso interno, pero **es una regla laxa**: cualquiera que entre con auth anónima a ese proyecto puede leer y escribir todo.
- **Pendiente / a mejorar**: la contraseña de casa matriz (`CM_PASSWORD`) está en texto plano en el código fuente de `gestion-3d.html`, que se sube a un repo público. Cualquiera que abra el HTML y busque esa constante puede activar el modo casa matriz sin ser realmente casa matriz. Queda pendiente decidir una forma mejor de proteger ese modo (por ejemplo, autenticación real contra Firebase en vez de una clave fija en el cliente).
- El número de WhatsApp del negocio (`WHATSAPP_NUMERO`, usado por el botón "Consultar por WhatsApp" del catálogo) también queda expuesto en el código fuente — es esperable, ya que cualquier botón de WhatsApp necesita mostrar el número tarde o temprano, pero vale la pena que sea un número "de cara al público" del taller y no el celular personal de nadie.

## `gestion-3d.html` — Modelo de vendedores y casa matriz

- **Vendedor**: cada persona que usa la app en su celular carga su nombre en Opciones → "Tu identificación" (sin login). Ese nombre (normalizado a slug) es la clave del documento Firestore donde sube sus propios datos: colección `vendedores/{slug(nombre)}` con `{ nombre, clients, orders, prospects, updatedAt }`.
- **Sincronización automática**: cada 5 minutos, y también al abrir la app. En modo vendedor: sube sus datos propios y baja los overrides de casa matriz. En modo casa matriz: sube los overrides y lee los datos de todos los vendedores dados de alta.
- **Casa matriz**: modo protegido por `CM_PASSWORD` (clave fija en el código, ver arriba). Una vez desbloqueado el dispositivo, puede:
  - Ver el consolidado de clientes y pedidos de todos los vendedores, con chip de filtro por vendedor.
  - Dar de alta/baja vendedores (colección local `cmVendedores`, no toca Firestore directamente salvo al leer sus documentos).
  - **Editar** clientes y pedidos — pero no pisa el registro original del vendedor: guarda el cambio como **override** aparte (`overrides/casaMatriz` en Firestore, `{ clients: {id: {campos, _at}}, orders: {...} }`). El override se aplica en el momento de mostrar el dato, tanto en la vista de casa matriz como en la vista propia del vendedor.
  - **Ver el detalle de un override**: el chip 🏢 que ve el vendedor sobre un cliente/pedido tocado por casa matriz ahora es clickeable — muestra qué campo cambió (valor viejo → valor nuevo) y cuándo, comparando el override contra el registro original.
  - **Eliminar pedidos**: mismo mecanismo de override, con `_eliminado: true`. El pedido deja de listarse en ambas vistas una vez que sincroniza; el dato real sigue existiendo en el documento del vendedor por si hay que revertirlo a mano.
  - **Dashboard** (📊, botón en el banner de casa matriz, solo visible en ese modo): total facturado del mes, total ya cobrado del mes, cantidad de pedidos del mes, pedidos por estado (consolidado), y comparación de facturación/cantidad de pedidos entre vendedores del mes actual. El vendedor normal no ve este dashboard.
  - **No puede**: crear pedidos nuevos, ni crear/eliminar clientes directamente, ni convertir un prospecto en cliente — eso lo hace cada vendedor desde su propia app.
- **Migración de datos viejos**: `migrarPedidosViejos()` convierte pedidos del formato antiguo (un solo producto/precio) al formato actual de lista de items. `migrarCobradoViejos()` inicializa el campo `cobrado` (ver más abajo) y el historial de estados en pedidos que no lo tenían, al cargar la app.

## `catalogo-3d.html` — Catálogo de productos

- Muestra los productos a los clientes (pensado para compartir el link por WhatsApp).
- Los productos se guardan en Firestore (colección `productos`, mismo proyecto `agenda-clientes-3s`) y se escuchan en vivo (`escucharProductos`), así que un cambio se ve reflejado sin recargar.
- **Categorías múltiples**: un producto puede tener varias categorías a la vez (campo `categorias`, array). Aparece **repetido en cada sección** de categoría a la que pertenece, tanto en el catálogo como en el selector de catálogo de `gestion-3d.html`. En el formulario de edición se cargan como etiquetas (chips con ✕ para quitar, input + botón "Agregar" o Enter para sumar). Hay compatibilidad hacia atrás con productos viejos que solo tenían `categoria` (string única) vía la función `categoriasDe(p)`, duplicada en ambos HTML.
  - **Limitación conocida**: el campo `orden` (usado por las flechas ↑↓) sigue siendo un único número por producto, no uno por categoría. Si un producto vive en dos categorías, reordenarlo en una puede correrle la posición en la otra. Es una simplificación consciente; si empieza a molestar en el uso real, conviene revisarlo.
- **Filtro por categoría**: chips debajo del buscador de texto, generados en base a las categorías cargadas (considera todas las categorías de cada producto).
- **Disponibilidad**: cada producto tiene `disponibilidad` (`inmediato` / `pedido`), con chip de color en la tarjeta y en el detalle ("✅ Hecho al momento" / "⏳ Bajo pedido"), además de los días de impresión que ya existían.
- **Orden manual**: en modo editor, flechas ↑↓ sobre cada tarjeta reordenan los productos dentro de la categoría de esa sección (campo `orden`, se persiste en Firestore). Si no hay `orden` explícito, se ordena alfabéticamente como antes.
- **Detalle del producto (sheet)**: botón de cerrar como **✕ circular fija arriba a la derecha**, superpuesta sobre la galería (no se va con el scroll aunque la descripción sea larga). Los botones de WhatsApp y compartir son **dos botones cuadrados con ícono** (SVG, sin texto) en vez de los dos botones largos originales — menos distracción visual.
- **Consultar por WhatsApp**: botón cuadrado en el detalle del producto que arma un mensaje pre-completado con nombre y precio y abre `wa.me`. Requiere completar `WHATSAPP_NUMERO` en el código (ver "Backend: Firebase" arriba).
- **Compartir un producto puntual**: botón cuadrado en el detalle que arma un link con `#id-del-producto` (usa `navigator.share` si está disponible, si no copia al portapapeles). Al abrir un link con hash, el catálogo detecta el `#id` al cargar y abre ese producto directo.
- **Fotos comprimidas antes de subir**: se redimensionan a un máximo de 1280px y se convierten a JPEG (calidad 0.8) en el propio celular antes de subirlas a GitHub — subida más rápida y catálogo más liviano para quien lo abre con datos móviles.
- **Reordenar fotos en el editor**: flechas ▲▼ sobre cada miniatura del formulario de edición, ya no hace falta borrar y resubir para cambiar el orden (la primera sigue siendo la portada).
- Modo "editor" protegido con clave local (`editorUnlocked` en localStorage) para cargar/editar productos y sus fotos.
- Las fotos de producto se suben directamente al repo de GitHub vía un token personal (`ghToken`, guardado en localStorage del celular donde se edita) — no se suben a Firebase Storage.
- Carrusel de fotos por producto con puntitos indicadores y `scroll-snap-stop: always`.
- **Botones en `gestion-3d.html` para abrir el catálogo (📋) y compartirlo (📤)** — ver flujo completo de compartir más abajo, en "Funcionalidades de `gestion-3d.html`".

## Funcionalidades de `gestion-3d.html` (resumen completo)

**Clientes**
- Nombre, teléfono, email, dirección, notas
- Teléfono normalizado al formato argentino para WhatsApp (`+54 9`, sin `0` inicial ni `15`)
- Tocar el teléfono abre un chat de WhatsApp directo
- Buscador en vivo, orden alfabético
- En modo casa matriz: campo extra de vendedor asignado, filtro por vendedor

**Pedidos**
- Varios productos por pedido (nombre, cantidad, precio unitario), total calculado solo
- Estados: En impresión / Listo para entregar / Entregado — **separado del cobro** (ver abajo)
- **Cobrado, aparte del estado**: cada pedido tiene un campo `cobrado` independiente del estado de entrega, para no perder el rastro de quién debe (fiado). Se ve como un chip aparte (💰 Cobrado / ⏳ Sin cobrar, tocable para togglear) y como checkbox en el formulario. Los pedidos viejos que estaban en "Entregado y cobrado" se migraron asumiendo `cobrado: true`.
- **Buscador en Pedidos**: filtra en vivo por nombre de producto o de cliente.
- **Aviso de fecha de entrega**: badge 🔴 "Vencido" / 🟡 "Vence hoy" en cada pedido con fecha cargada y no entregado; chip para filtrar solo esos, y un criterio de orden ("Vencidos / vencen hoy primero").
- **Historial de cambios de estado**: cada vez que el estado cambia se guarda `{estado, at}` (hasta los últimos 20 cambios), visible en modo lectura dentro del formulario de edición del pedido.
- Ordenamiento por varios criterios (recientes/antiguos, cliente A-Z, producto A-Z, fecha de entrega, vencidos primero, precio, estado)
- En modo casa matriz: puede editar y eliminar (ver override `_eliminado` arriba)

**Prospectos**
- Nombre del lugar + nota corta + fecha, pensado para cargar rápido parado en la calle
- **Convertir en cliente**: botón "→ Cliente" que abre el formulario de cliente precargado con nombre y nota; al guardar, borra el prospecto original (no disponible en modo casa matriz).
- **Ubicación GPS**: se captura sola al guardar el prospecto (sin bloquear si no hay permiso o señal), con link "📍 Ver ubicación" a Google Maps cuando está disponible.

**Otros**
- Tamaño de letra ajustable (80%–150%)
- Exportar/importar copia de seguridad en `.json` (respaldo manual, independiente de Firebase)
- Ícono propio para pantalla de inicio
- **Compartir catálogo por WhatsApp (botón 📤)**: en vez de un share genérico, abre un selector: elegir un **cliente ya guardado** (busca por nombre o teléfono) o escribir un **número nuevo**. Si el número es nuevo, ofrece guardarlo en Clientes ahí mismo (nombre + checkbox tildado por default) para no perder contactos que todavía no estaban agendados — típicamente gente nueva que se cruza en la calle. Al confirmar, abre `wa.me` directo a ese número con el link del catálogo. Queda un botón secundario "Compartir de otra forma" con el share nativo / copiar al portapapeles, para casos sin WhatsApp. En modo casa matriz no se ofrece guardar el contacto nuevo (mismo criterio que con clientes: el alta la hace cada vendedor desde su propia app), pero sí puede elegir un cliente ya guardado del consolidado.

## Modelo de datos (referencia rápida)

```
clients:   { id, nombre, telefono, email, direccion, notas, createdAt,
             documentoUrl,      // reservado, ver "Ganchos pendientes"
             vendedor }         // nombre del vendedor dueño del registro

orders:    { id, clienteId, fecha, estado, cobrado, createdAt, vendedor,
             items: [ { id, nombre, cantidad, precio } ],
             historialEstados: [ { estado, at } ] }   // hasta los últimos 20
             // el total NO se guarda: se calcula sumando cantidad × precio
             // "estado" ya NO implica cobro: cobrado es un campo aparte

prospects: { id, nombre, nota, createdAt,
             lat, lng }         // coordenadas GPS si se pudieron capturar

overrides/casaMatriz (doc único en Firestore):
             { clients: { [id]: { campos, _at } },
               orders:  { [id]: { campos, _at } } }
             // campos puede incluir _eliminado: true para pedidos borrados
             // por casa matriz sin tocar el documento del vendedor

vendedores/{slug(nombre)} (un doc por vendedor en Firestore):
             { nombre, clients, orders, prospects, updatedAt }

productos (colección en Firestore, usada por catalogo-3d.html):
             { id, nombre, categorias: [ ... ],  // array; "categoria" (string) se mantiene
               categoria,        // = categorias[0], solo por compatibilidad hacia atrás
               precio, diasImpresion,
               disponibilidad,   // 'inmediato' | 'pedido'
               orden,            // número, para el orden manual dentro de cada categoría
               fotos: [ url, ... ], descripcion }
```

En el celular, cada tabla local se guarda como una key en `localStorage`:
`taller3d_clients`, `taller3d_orders`, `taller3d_prospects`, `taller3d_fontScale`, `taller3d_vendorName`, `taller3d_cmUnlocked`, `taller3d_cmModo`, `taller3d_cmVendedores`, `taller3d_overridesCache`.

En `catalogo-3d.html`: `editorUnlocked` y el token de GitHub para subir fotos.

## Ganchos dejados para funciones futuras (sin usar todavía)

- **`documentoUrl` en cada cliente**: reservado para integrar Google Drive. Falta definir: ¿un doc por cliente? ¿carpeta compartida con subcarpetas? ¿qué tipo de documentación (presupuestos, diseños 3D, comprobantes)?
- **Mapa de prospectos**: ya se captura `lat`/`lng` al cargar cada prospecto (con link directo a Google Maps), pero falta la vista de mapa con todos los pines juntos si se quiere más adelante.

## Pendientes conocidos

- **Seguridad de casa matriz**: la clave (`CM_PASSWORD`) está fija en el código fuente público. A mejorar (ver "Backend: Firebase" arriba).
- **Reglas de Firestore laxas**: cualquier auth anónima puede leer/escribir todo el proyecto. Aceptable por ahora dado el uso interno, pero vale la pena revisar si el proyecto crece.
- **Alta de clientes/pedidos desde casa matriz**: hoy no está permitido: hay que decidir el flujo si se quiere habilitar (a qué vendedor se le asignaría el registro nuevo).
- **`WHATSAPP_NUMERO` sin completar**: quedó como constante vacía en `catalogo-3d.html`; hay que poner el número real del negocio en formato internacional sin `+` (ej. `5492215551234`) para que funcione el botón "Consultar por WhatsApp".
- **Orden manual con categorías múltiples**: el campo `orden` es único por producto, no uno por categoría; si un producto vive en dos categorías, reordenarlo en una puede correrle la posición en la otra (ver detalle en la sección de `catalogo-3d.html`).

## Decisiones de diseño (para mantener consistencia si se sigue iterando)

- **Paleta**: fondo grafito oscuro `#1b1d21`, superficies `#24272c` / `#2c3037`, acento "filamento" naranja `#ff7a29`. Estados de pedido: azul `#60a5fa` (en impresión), amarillo `#fbbf24` (listo), verde `#34d399` (entregado). Disponibilidad de producto: verde (`#34d399`) hecho al momento, amarillo (`#fbbf24`) bajo pedido.
- **Tipografía**: Inter para texto general, JetBrains Mono para números, precios y etiquetas técnicas.
- **Detalle de marca**: el encabezado tiene una textura sutil de líneas horizontales que simulan capas de impresión 3D.
- **Layout**: mobile-first, navegación inferior de 3 pestañas (Clientes / Pedidos / Prospectos), formularios como "bottom sheets", botón flotante ＋ para agregar.

## Cómo seguir en otro chat

1. Iniciar el chat **dentro de este mismo proyecto**, para que este documento ya esté disponible como contexto.
2. Adjuntar la **última versión** de `gestion-3d.html`, `catalogo-3d.html`, `sw.js` y `sw-catalogo.js` que estén realmente subidas al repo.
3. Pedir explícitamente que lea los archivos enteros antes de modificar nada.
4. Si lo que se pide es grande o ambiguo (por ejemplo, tocar las reglas de Firestore o la seguridad de casa matriz), conviene aclarar antes el comportamiento exacto esperado.

## Recordatorios a repetir en el próximo chat

- Cada vez que se sube una versión nueva de `gestion-3d.html` o `catalogo-3d.html`, subir también el número de `CACHE_NAME` en su `sw` correspondiente (`sw.js` o `sw-catalogo.js`), si no los celus con la app ya instalada van a seguir viendo la versión vieja.
- Los datos "de verdad" ya viven en Firebase (no solo en el celular), pero conviene seguir usando el export/import `.json` como respaldo manual adicional.
- Al tocar el modelo de overrides de casa matriz, recordar que la idea de fondo es "nunca pisar el dato original del vendedor, todo cambio de casa matriz va como override aparte".
- Falta completar `WHATSAPP_NUMERO` en `catalogo-3d.html` con el número real del negocio.
